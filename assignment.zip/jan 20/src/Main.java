import Model.Cat;

public class Main {
    Cat cat1 = new Cat("neon",true,"home");
}
